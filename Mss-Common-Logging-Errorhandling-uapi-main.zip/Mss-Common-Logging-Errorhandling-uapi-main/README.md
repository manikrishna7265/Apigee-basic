# Mss-Common-Logging-Errorhandling-uapi

### Contents 
1.1 Introduction  
1.2 What is Utility service 
1.3 Setting up the Utility service 
1.4 Using Utility service for error handling 
Global Error Handler

### 1.1 Introduction  

Application logging and error handling are essential components of log management that aid in the efficient operation of a business. It is difficult to identify the events without a suitable logging record, which makes debugging a drawn-out and time-consuming task. 

In general, developers utilise various logging techniques to record events, but in the event of a problem, it is a default to locate the necessary information that is useful for debugging. Again, this necessitates a protracted process of further coding or debugging to obtain the pertinent information. 

We have built a framework for Utility Service error handling to address the aforementioned cases. By doing this, any MuleSoft API standardises the message logging and exception handling scenarios. The developer's efforts are minimised by the out-of-the-box utility service.

### 1.2 What is Utility Service? 

Utility Service is a framework that logs the mule messages with all the required information that would be helpful for troubleshooting. It has the capability to log the mule message in different formats. 
Services offered by Utility Service: 
• It supports different log formats.
• No additional formatting/logging is required and is easily publishable to data aggregation platforms like Splunk, ELK, and others.
• It calculates the latency from start to end across layers, which is useful to monitor the performance of the application. 
• Request level details can be tracked using TransactionID. The TransactionID will be unique for each transaction.
• Additionally, it supports up to 10 context keys to log any other information
• It will propagate the actual error details to the consumer even in the case of API-led approach.
• One can easily configure to log the original and errored payloads.
• Logs the source and target names which are helpful for the support team.
Different formats supported by Utility Service: 
• JSON
• XML

### 1.3 Setting up the Utility Service

1. Downlaod the Mss-common-logging and Error handling utility api code to your Local System

2. Import the file to Anypoint platform

![](images/1.png)

3.Later select a file type as Anypoint studio project from file system

![](images/2.png)

4.Now give the path to add into Anypoint studio

![](images/3.png)

5.Now, we able to see the project in your Anypoint studio

![](images/4.png)

6.Right click on Project-->properties to open root path Location of the project

![](images/5.png)

![](images/6.png)

7.Open Command prompt from the project loaction


![](images/7.png)

8.Enter the below command to generate a Jar file

  		  mvn clean install
 
![](images/8.png)

9.We able to see the "Build Success" message means the jar was generated into your m2 repository

![](images/9.png)

![](images/10.png)

10.Now plugin the cle project to your desired project by following the below steps.

11. Add the below dependency to your mule project pom.xml 

  		<dependency>
			<groupId>com.mss-utilityservice</groupId>
			<artifactId>mss-utility-service-cle</artifactId>
			<version>1.0.0</version>
			<classifier>mule-plugin</classifier>
		</dependency>


![](images/11.png)

12. After adding the dependcy save and right clickk on project-->properties to the project Location


![](images/12.png)

13. Open command prompt from the project location.

![](images/13.png)

14.Enter the below command to install CLE module into your project

 		mvn install:install-file -Dfile=\D:\cle\mss-utility-service-cle-5.0.0-SNAPSHOT-mule-plugin.jar -DgroupId=com.mss-utilityservice -DartifactId=mss-utility-service-cle -Dversion=5.0.0-SNAPSHOT -Dpackaging=jar -DgeneratePom=true

![](images/14.png)

15. After getting success message from the console

![](images/15.png)

16.We will able to see CLE utility module in your project.

![](images/16.png)

17.Import “globalLogger.xml” from the utility service into your project global elements and use the utility service for logging and error handling. 

Code snippet: 

<import doc:name="Import" doc:id="1e7228fe-5c6c-4570-9b78-5aa2e688e340" file="globalLogger.xml" />


![](images/17.png)

![](images/18.png)

18.Utility service is simply used by calling the flows defined using Flow Reference. From here, it automatically handles the errors and logs the transaction in the specified format. 

 ![](images/19.png)



